public class Main {
    public static void main(String[] args) {
        int i = true; // Error: Cannot assign boolean to int
    }
}
